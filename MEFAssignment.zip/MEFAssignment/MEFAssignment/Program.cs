﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Reflection;
using System.IO;
using Newtonsoft.Json;
using System.Xml;

namespace MEFAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            
              if (!(args == null) && (args.Length == 2))
              {
                var _BootStrap = new Bootstrap();
                var service = _BootStrap.GetService();
                //  var reader = service.GetReader(@"C:\Users\BQ88WKd\MEFAssignment\MEFAssignment\temp", "xml");
                 var reader = service.GetReader(args[0], args[1]);

              List<string> lstServer =   reader.ReadAllServer();
              Console.WriteLine("All Server\n");
              foreach (var item in lstServer)
	            {
                    Console.WriteLine(item);
                    
	            }
              Console.WriteLine("\n");
              List<string> lstEndpoints = reader.ReadAllEndPoints();
              Console.WriteLine("All Endpoints\n");
              foreach (var item in lstEndpoints)
              {
                  Console.WriteLine(item);
                  
              }
              Console.WriteLine("\n");   
                List<string> lstActiveEndpoints = reader.ReadActiveEndPoints();
                Console.WriteLine("All Active Endpoints\n");
                foreach (var item in lstActiveEndpoints)
                {
                    Console.WriteLine(item);
                    
                }
                Console.WriteLine("\n");
                List<EndPointInformation> lstEndPointInfo = reader.ReadServersEndPointsInformation();
                Console.WriteLine("Information for an endpoint \n");
                foreach (var item in lstEndPointInfo)
                {
                    Console.Write(item.EndPointName+" ");
                    Console.Write(item.Server + " ");
                    Console.Write(item.Enabled + " ");
                    Console.WriteLine("\n");
                }

              }
              else
              {
                   Console.WriteLine("Enter location configuration file(e.g. c:\temp) and type of file(json or xml) as argument");
                   Console.Read();
              }

                
        }
    }



    public class Bootstrap
    {
        private static CompositionContainer _container;
        public Bootstrap()
        {
            AssemblyCatalog catalog = new AssemblyCatalog(Assembly.GetExecutingAssembly());
            _container = new CompositionContainer(catalog);

        }
        public Iservice GetService()
        {
            return _container.GetExportedValue<Iservice>();
        }

    }



    public interface Iservice
    {

        IReader GetReader(string location, string format);

    }
    [Export(typeof(Iservice))]
    public class BusinessService : Iservice
    {
        [ImportMany(typeof(IReader))]
        public List<Lazy<IReader, IReaderMetaData>> Readers; // need to clarify



        public BusinessService()
        {

        }
        public IReader GetReader(string location, string format)
        {
            IReader Reader = null;

            Lazy<IReader> reader = Readers.FirstOrDefault(r => r.Metadata.Format == format);
            if (reader != null)
            {
                Reader = reader.Value;
                Reader.location = location;
            }
            return Reader;
        }



    }


    public interface IReaderMetaData
    {
        string Format { get; }
    }

    public interface IReader
    {
        
        string location { get; set; }

        List<string> ReadAllServer();
        List<string> ReadAllEndPoints();
        List<string> ReadActiveEndPoints();
        string ReadServersEndPointsDetails();
        List<EndPointInformation> ReadServersEndPointsInformation();
    }

    public class EndPoint
    {
        public string Name { get; set; }
        public bool Enabled { get; set; }
    }

    public class EndPointInformation
    {
        public string Server { get; set; }

        public string EndPointName { get; set; }

        public Boolean Enabled { get; set; }

    }



    [Export(typeof(IReader)), ExportMetadata("Format", "json")]
    public class JsonReader : IReader
    {
        
        public string location { get; set; }

     
        public List<string> ReadAllServer()
        {

            List<string> dirList = new List<string>();

            foreach (string s in Directory.GetDirectories(location))
            {

                DirectoryInfo dir_info = new DirectoryInfo(s);
                string directory = dir_info.Name;
                dirList.Add(dir_info.Name);
            }
            return dirList;

        }

        public List<string> ReadAllEndPoints()
        {
            List<string> lstEndpoints = new List<string>();
            foreach (string file in Directory.EnumerateFiles(location, "*.json*", SearchOption.AllDirectories))
            {

                using (StreamReader r = new StreamReader(file))
                {

                    string json = r.ReadToEnd();

                    List<EndPoint> endpoints = JsonConvert.DeserializeObject<List<EndPoint>>(json);
                    foreach (var endPoint in endpoints)
                    {
                        lstEndpoints.Add(endPoint.Name);

                    }
                }

            }

            return lstEndpoints;
        }

        public List<string> ReadActiveEndPoints()
        {
            List<string> lstEndpoints = new List<string>();
            foreach (string file in Directory.EnumerateFiles(location, "*.json*", SearchOption.AllDirectories))
            {

                using (StreamReader r = new StreamReader(file))
                {

                    string json = r.ReadToEnd();

                    List<EndPoint> endpoints = JsonConvert.DeserializeObject<List<EndPoint>>(json);
                    foreach (var endPoint in endpoints)
                    {
                        if (endPoint.Enabled)
                        {
                            lstEndpoints.Add(endPoint.Name);
                        }
                    }
                }

            }

            return lstEndpoints;
        }

        public string ReadServersEndPointsDetails()
        {
            return "";
        }

        

        public List<EndPointInformation> ReadServersEndPointsInformation()
        {
            List<EndPointInformation> endpointInfoList = new List<EndPointInformation>();
            var directories = Directory.GetDirectories(location);
            foreach (var dir in directories)
            {

                DirectoryInfo dir_info = new DirectoryInfo(dir);
                string directory = dir_info.Name;

                EndPointInformation endpointInfo = new EndPointInformation();
                endpointInfo.Server = directory;

                string[] files = Directory.GetFiles(dir, "*.json");
                if (files.Count() > 0)
                {
                    foreach (string file in files)
                    {
                        using (StreamReader r = new StreamReader(file))
                        {

                            string json = r.ReadToEnd();

                            List<EndPoint> endpoints = JsonConvert.DeserializeObject<List<EndPoint>>(json);
                            foreach (var endPoint in endpoints)
                            {
                                endpointInfo.EndPointName = endPoint.Name;
                                endpointInfo.Enabled = endPoint.Enabled;
                                endpointInfoList.Add(endpointInfo);
                            }
                        }
                    }
                    
                }
            }

            return endpointInfoList;
        }

    }
    [Export(typeof(IReader)), ExportMetadata("Format", "xml")]
    public class XmLReader : IReader
    {
        
        public string location { get; set; }
  
        public List<string> ReadAllServer()
        {
            List<string> dirList = new List<string>();

            foreach (string s in Directory.GetDirectories(location))
            {

                DirectoryInfo dir_info = new DirectoryInfo(s);
                string directory = dir_info.Name;
                dirList.Add(dir_info.Name);
            }
            return dirList;

        }

        public List<string> ReadAllEndPoints()
        {
            List<string> lstEndpoints = new List<string>();

            foreach (string file in Directory.EnumerateFiles(location, "*.xml*", SearchOption.AllDirectories))
            {
                XmlDocument myXmlDocument = new XmlDocument();
                myXmlDocument.Load(file);
                XmlNodeList list = myXmlDocument.SelectNodes("endpoints");
                foreach (XmlNode node in list)
                {
                    XmlNodeList lst = node.ChildNodes;
                    foreach (XmlNode endpoint in lst)
                    {
                        lstEndpoints.Add(endpoint.Attributes["name"].Value);
                    }
                }
            }

            return lstEndpoints;

        }

        public List<string> ReadActiveEndPoints()
        {
            List<string> lstEndpoints = new List<string>();

            foreach (string file in Directory.EnumerateFiles(location, "*.xml*", SearchOption.AllDirectories))
            {
                XmlDocument myXmlDocument = new XmlDocument();
                myXmlDocument.Load(file);
                XmlNodeList list = myXmlDocument.SelectNodes("endpoints");
                foreach (XmlNode node in list)
                {
                    XmlNodeList lst = node.ChildNodes;
                    foreach (XmlNode endpoint in lst)
                    {
                        if (endpoint.InnerText == "true")
                        {
                            lstEndpoints.Add(endpoint.Attributes["name"].Value);
                        }

                    }
                }
            }

            return lstEndpoints;
        }

        public string ReadServersEndPointsDetails()
        {
            return "";
        }



        public List<EndPointInformation> ReadServersEndPointsInformation()
        {
            List<EndPointInformation> endpointInfoList = new List<EndPointInformation>();
            var directories = Directory.GetDirectories(location);
            foreach (var dir in directories)
            {

                string[] files = Directory.GetFiles(dir, "*.xml");
                if (files.Count() > 0)
                {
                    foreach (string file in files)
                    {
                        XmlDocument myXmlDocument = new XmlDocument();
                        myXmlDocument.Load(file);
                        XmlNodeList list = myXmlDocument.SelectNodes("endpoints");
                        foreach (XmlNode node in list)
                        {
                            XmlNodeList lst = node.ChildNodes;
                            foreach (XmlNode endpoint in lst)
                            {


                                DirectoryInfo dir_info = new DirectoryInfo(dir);
                                string directory = dir_info.Name;

                                EndPointInformation endpointInfo = new EndPointInformation();
                                endpointInfo.Server = directory;
                                endpointInfo.EndPointName = endpoint.Attributes["name"].Value;
                                if (endpoint.InnerText == "true")
                                {
                                    endpointInfo.Enabled = true;
                                }
                                else
                                {
                                    endpointInfo.Enabled = false;

                                }

                                endpointInfoList.Add(endpointInfo);

                            }
                        }
                    }
                }


            }
            return endpointInfoList;
        }



    


    }
}





